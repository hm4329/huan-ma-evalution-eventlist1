const API_URL = "http://localhost:3000/events";

// Initialize events by fetching data from the server
async function initializeEvents() {
  try {
    const response = await fetch(API_URL);
    const events = await response.json();
    events.forEach((event) => addRowToTable(event));
  } catch (error) {
    console.error("Failed to load events:", error);
  }
}
function addEvent() {
  const addButton = document.getElementById("add-event-button");

  addButton.addEventListener("click", () => {
    const tableBody = document.getElementById("todo-table-body");

    // Add a new row with input fields
    const row = document.createElement("tr");
    row.innerHTML = `
        <td><input type="text" class="event-name-input" placeholder="Enter Event Name"></td>
        <td><input type="date" class="start-date-input"></td>
        <td><input type="date" class="end-date-input"></td>
        <td>
          <button class="save-btn">Save</button>
          <button class="cancel-btn">Cancel</button>
        </td>
      `;

    const saveButton = row.querySelector(".save-btn");
    const cancelButton = row.querySelector(".cancel-btn");

    saveButton.addEventListener("click", async () => {
      const eventName = row.querySelector(".event-name-input").value;
      const startDate = row.querySelector(".start-date-input").value;
      const endDate = row.querySelector(".end-date-input").value;

      if (!eventName || !startDate || !endDate) {
        alert("All fields are required!");
        return;
      }

      const newEvent = { eventName, startDate, endDate };

      try {
        const response = await fetch(API_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(newEvent),
        });

        if (!response.ok) throw new Error("Failed to add event.");

        const savedEvent = await response.json();
        tableBody.removeChild(row); // Remove the input row
        addRowToTable(savedEvent); // Add a new row with saved data
      } catch (error) {
        console.error("Error adding event:", error);
      }
    });

    cancelButton.addEventListener("click", () => {
      tableBody.removeChild(row);
    });

    tableBody.appendChild(row);
  });
}
function addRowToTable(event) {
  const tableBody = document.getElementById("todo-table-body");
  const row = document.createElement("tr");

  row.innerHTML = `
      <td>${event.eventName}</td>
      <td>${event.startDate}</td>
      <td>${event.endDate}</td>
      <td>
        <button class="edit-btn">Edit</button>
        <button class="delete-btn">Delete</button>
      </td>
    `;

  const editButton = row.querySelector(".edit-btn");
  const deleteButton = row.querySelector(".delete-btn");

  editButton.addEventListener("click", () => {
    row.innerHTML = `
        <td><input type="text" class="event-name-input" value="${event.eventName}"></td>
        <td><input type="date" class="start-date-input" value="${event.startDate}"></td>
        <td><input type="date" class="end-date-input" value="${event.endDate}"></td>
        <td>
          <button class="save-btn">Save</button>
          <button class="cancel-btn">Cancel</button>
        </td>
      `;

    const saveButton = row.querySelector(".save-btn");
    const cancelButton = row.querySelector(".cancel-btn");

    saveButton.addEventListener("click", async () => {
      const updatedEvent = {
        id: event.id,
        eventName: row.querySelector(".event-name-input").value,
        startDate: row.querySelector(".start-date-input").value,
        endDate: row.querySelector(".end-date-input").value,
      };

      try {
        const response = await fetch(`${API_URL}/${event.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(updatedEvent),
        });

        if (!response.ok) throw new Error("Failed to update event.");

        const savedEvent = await response.json();
        row.innerHTML = `
            <td>${savedEvent.eventName}</td>
            <td>${savedEvent.startDate}</td>
            <td>${savedEvent.endDate}</td>
            <td>
              <button class="edit-btn">Edit</button>
              <button class="delete-btn">Delete</button>
            </td>
          `;

        attachRowHandlers(row, savedEvent);
      } catch (error) {
        console.error("Error updating event:", error);
      }
    });

    cancelButton.addEventListener("click", () => {
      addRowToTable(event);
      tableBody.removeChild(row);
    });
  });

  deleteButton.addEventListener("click", async () => {
    if (confirm(`Are you sure you want to delete "${event.eventName}"?`)) {
      try {
        const response = await fetch(`${API_URL}/${event.id}`, {
          method: "DELETE",
        });

        if (!response.ok) throw new Error("Failed to delete event.");

        tableBody.removeChild(row);
      } catch (error) {
        console.error("Error deleting event:", error);
      }
    }
  });

  tableBody.appendChild(row);
}
(async function initApp() {
  await initializeEvents(); // Load existing events
  addEvent(); // Attach event listener for adding events
})();
